# Copyright (C) 2025 Francesco Piroddi
# Questo programma è distribuito sotto licenza GPL 3.0
# Puoi ridistribuirlo e/o modificarlo secondo i termini della GNU General Public License, pubblicata dalla Free Software Foundation, versione 3 o successive.
# Questo programma è distribuito nella speranza che sia utile, ma SENZA ALCUNA GARANZIA; senza neppure la garanzia implicita di COMMERCIABILITÀ o IDONEITÀ PER UN PARTICOLARE SCOPO. Vedi la GNU General Public License per maggiori dettagli.

def calcola_percorso_di_vita(data_nascita):
    def somma_cifre(numero):
        while numero > 9 and numero not in {11, 22, 33}:  # Manteniamo i numeri maestri
            numero = sum(int(cifra) for cifra in str(numero))
        return numero
    
    giorno, mese, anno = map(int, data_nascita.split("/"))
    numero_percorso = somma_cifre(giorno) + somma_cifre(mese) + somma_cifre(anno)
    return somma_cifre(numero_percorso)

def significato_percorso(percorso):
    significati = {
        1: ("Leader", "Ambizioso, indipendente, determinato. Deve imparare a bilanciare l’ambizione con l’empatia."),
        2: ("Diplomatico", "Cooperativo, sensibile, pacifico. Eccelle nel creare armonia nelle relazioni."),
        3: ("Creativo", "Espressivo, artistico, socievole. Ha una grande immaginazione e carisma."),
        4: ("Costruttore", "Affidabile, pratico, disciplinato. Ha un forte senso di responsabilità e lavoro duro."),
        5: ("Avventuriero", "Libero, curioso, dinamico. Ha bisogno di varietà e nuove esperienze."),
        6: ("Custode", "Responsabile, amorevole, familiare. Ha una forte vocazione per l’aiuto agli altri."),
        7: ("Cercatore", "Intuitivo, riflessivo, spirituale. Ama la conoscenza e la ricerca della verità."),
        8: ("Potente", "Ambizioso, orientato al successo, leader. Ha un talento naturale per il business e il potere."),
        9: ("Saggio", "Altruista, compassionevole, visionario. Ha una visione globale e un cuore generoso."),
        11: ("Intuitivo", "Visionario, sensibile, ispiratore. Deve imparare a gestire le sue energie spirituali."),
        22: ("Maestro Costruttore", "Ambizioso, pratico, innovatore. Destinato a lasciare un impatto duraturo nel mondo."),
        33: ("Maestro Guaritore", "Compassionevole, illuminato, amorevole. Ha il compito di portare amore e saggezza su larga scala.")
    }
    return significati.get(percorso, ("Numero non valido", ""))

if __name__ == "__main__":
    data = input("Inserisci la tua data di nascita (GG/MM/AAAA): ")
    numero_percorso = calcola_percorso_di_vita(data)
    titolo, descrizione = significato_percorso(numero_percorso)
    print(f"Il tuo Numero del Percorso di Vita è: {numero_percorso} - {titolo}")
    print(f"Caratteristiche: {descrizione}")
